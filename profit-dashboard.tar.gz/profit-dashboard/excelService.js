const ExcelJS = require('exceljs');
const path = require('path');
const fs = require('fs');

class ExcelService {
    constructor(basePath) {
        this.basePath = basePath;
        this.workbooks = {}; // Cache workbooks in memory
    }

    getFilePath(month, year) {
        return path.join(this.basePath, `Profit_Dashboard_${year}_${month}.xlsx`);
    }

    getBackupPath(month, year) {
        const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
        return path.join(this.basePath, 'backups', `Backup_${year}_${month}_${timestamp}.xlsx`);
    }

    async loadOrCreateMonthFile(month, year) {
        const filePath = this.getFilePath(month, year);
        
        if (fs.existsSync(filePath)) {
            return await this.loadExistingFile(month, year);
        } else {
            return await this.createNewFile(month, year);
        }
    }

    async loadExistingFile(month, year) {
        const filePath = this.getFilePath(month, year);
        const workbook = new ExcelJS.Workbook();
        
        try {
            await workbook.xlsx.readFile(filePath);
            this.workbooks[`${year}-${month}`] = workbook;
            
            const projects = await this.readProjectsFromWorkbook(workbook);
            return projects;
        } catch (error) {
            console.error('Error loading Excel file:', error);
            throw error;
        }
    }

    async createNewFile(month, year) {
        const workbook = new ExcelJS.Workbook();
        
        // Create Projects Sheet
        const projectsSheet = workbook.addWorksheet('Projects');
        
        // Define headers with styling
        projectsSheet.columns = [
            { header: 'Project Name', key: 'projectName', width: 25 },
            { header: 'No. of Engineers', key: 'numEngineers', width: 15 },
            { header: 'Engineer Salary/Month', key: 'engineerSalary', width: 20 },
            { header: 'CE Visit Charge', key: 'ceVisitCharge', width: 18 },
            { header: 'Visits/Month', key: 'visitsPerMonth', width: 15 },
            { header: 'Transport Cost/Month', key: 'transportCost', width: 20 },
            { header: 'Client Payment/Month', key: 'clientPayment', width: 20 },
            { header: 'Overhead Allocation %', key: 'overheadAllocation', width: 20 },
            { header: 'Engineer Cost', key: 'engineerCost', width: 18 },
            { header: 'CE Visit Cost', key: 'ceVisitCost', width: 18 },
            { header: 'Direct Cost', key: 'directCost', width: 18 },
            { header: 'Overhead Cost', key: 'overheadCost', width: 18 },
            { header: 'Total Cost', key: 'totalCost', width: 18 },
            { header: 'Profit', key: 'profit', width: 18 },
            { header: 'Timestamp', key: 'timestamp', width: 22 }
        ];

        // Style the header row
        const headerRow = projectsSheet.getRow(1);
        headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        headerRow.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FF0066CC' }
        };
        headerRow.alignment = { vertical: 'middle', horizontal: 'center' };
        headerRow.height = 25;

        // Create Summary Sheet
        const summarySheet = workbook.addWorksheet('Summary');
        summarySheet.columns = [
            { header: 'Metric', key: 'metric', width: 30 },
            { header: 'Value', key: 'value', width: 20 }
        ];

        const summaryHeaderRow = summarySheet.getRow(1);
        summaryHeaderRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
        summaryHeaderRow.fill = {
            type: 'pattern',
            pattern: 'solid',
            fgColor: { argb: 'FF00AA00' }
        };
        summaryHeaderRow.alignment = { vertical: 'middle', horizontal: 'center' };
        summaryHeaderRow.height = 25;

        // Add summary formulas
        summarySheet.addRow({ metric: 'Total Projects', value: { formula: '=COUNTA(Projects!A2:A1000)' } });
        summarySheet.addRow({ metric: 'Total Revenue', value: { formula: '=SUM(Projects!G2:G1000)' } });
        summarySheet.addRow({ metric: 'Total Costs', value: { formula: '=SUM(Projects!M2:M1000)' } });
        summarySheet.addRow({ metric: 'Net Profit', value: { formula: '=B3-B4' } });

        // Format summary values as currency
        for (let i = 2; i <= 5; i++) {
            const cell = summarySheet.getCell(`B${i}`);
            cell.numFmt = '$#,##0.00';
        }

        // Save the file
        const filePath = this.getFilePath(month, year);
        await workbook.xlsx.writeFile(filePath);
        
        this.workbooks[`${year}-${month}`] = workbook;
        
        return [];
    }

    async readProjectsFromWorkbook(workbook) {
        const projectsSheet = workbook.getWorksheet('Projects');
        const projects = [];

        projectsSheet.eachRow((row, rowNumber) => {
            if (rowNumber === 1) return; // Skip header

            const project = {
                projectName: row.getCell(1).value,
                numEngineers: row.getCell(2).value,
                engineerSalary: row.getCell(3).value,
                ceVisitCharge: row.getCell(4).value,
                visitsPerMonth: row.getCell(5).value,
                transportCost: row.getCell(6).value,
                clientPayment: row.getCell(7).value,
                overheadAllocation: row.getCell(8).value,
                engineerCost: row.getCell(9).value,
                ceVisitCost: row.getCell(10).value,
                directCost: row.getCell(11).value,
                overheadCost: row.getCell(12).value,
                totalCost: row.getCell(13).value,
                profit: row.getCell(14).value,
                timestamp: row.getCell(15).value
            };

            if (project.projectName) {
                projects.push(project);
            }
        });

        return projects;
    }

    async saveProject(month, year, projectData) {
        const key = `${year}-${month}`;
        let workbook = this.workbooks[key];

        if (!workbook) {
            await this.loadOrCreateMonthFile(month, year);
            workbook = this.workbooks[key];
        }

        const projectsSheet = workbook.getWorksheet('Projects');
        
        // Get the next row number
        const nextRowNumber = projectsSheet.rowCount + 1;
        
        // Add the project row with formulas
        const newRow = projectsSheet.addRow({
            projectName: projectData.projectName,
            numEngineers: projectData.numEngineers,
            engineerSalary: projectData.engineerSalary,
            ceVisitCharge: projectData.ceVisitCharge,
            visitsPerMonth: projectData.visitsPerMonth,
            transportCost: projectData.transportCost,
            clientPayment: projectData.clientPayment,
            overheadAllocation: projectData.overheadAllocation,
            engineerCost: { formula: `=B${nextRowNumber}*C${nextRowNumber}` },
            ceVisitCost: { formula: `=D${nextRowNumber}*E${nextRowNumber}` },
            directCost: { formula: `=I${nextRowNumber}+J${nextRowNumber}+F${nextRowNumber}` },
            overheadCost: { formula: `=K${nextRowNumber}*(H${nextRowNumber}/100)` },
            totalCost: { formula: `=K${nextRowNumber}+L${nextRowNumber}` },
            profit: { formula: `=G${nextRowNumber}-M${nextRowNumber}` },
            timestamp: new Date().toISOString()
        });

        // Format numeric cells
        for (let col = 2; col <= 14; col++) {
            const cell = newRow.getCell(col);
            if (col >= 3 && col !== 5 && col !== 8 && col !== 2) { // Format as currency except for counts and percentages
                cell.numFmt = '$#,##0.00';
            } else if (col === 8) { // Format percentage
                cell.numFmt = '0.00"%"';
            }
        }

        // Save the file
        const filePath = this.getFilePath(month, year);
        await workbook.xlsx.writeFile(filePath);
        
        return projectData;
    }

    async deleteProject(month, year, projectName) {
        const key = `${year}-${month}`;
        let workbook = this.workbooks[key];

        if (!workbook) {
            await this.loadOrCreateMonthFile(month, year);
            workbook = this.workbooks[key];
        }

        const projectsSheet = workbook.getWorksheet('Projects');
        let rowToDelete = null;

        projectsSheet.eachRow((row, rowNumber) => {
            if (rowNumber === 1) return; // Skip header
            if (row.getCell(1).value === projectName) {
                rowToDelete = rowNumber;
            }
        });

        if (rowToDelete) {
            projectsSheet.spliceRows(rowToDelete, 1);
            const filePath = this.getFilePath(month, year);
            await workbook.xlsx.writeFile(filePath);
        }
    }

    async getProjects(month, year) {
        const key = `${year}-${month}`;
        let workbook = this.workbooks[key];

        if (!workbook) {
            return await this.loadOrCreateMonthFile(month, year);
        }

        return await this.readProjectsFromWorkbook(workbook);
    }

    async exportFile(month, year, destinationPath) {
        const sourcePath = this.getFilePath(month, year);
        
        if (!fs.existsSync(sourcePath)) {
            throw new Error('Source file does not exist');
        }

        fs.copyFileSync(sourcePath, destinationPath);
    }

    async createBackup(month, year) {
        const sourcePath = this.getFilePath(month, year);
        
        if (!fs.existsSync(sourcePath)) {
            throw new Error('Source file does not exist');
        }

        const backupPath = this.getBackupPath(month, year);
        const backupDir = path.dirname(backupPath);

        if (!fs.existsSync(backupDir)) {
            fs.mkdirSync(backupDir, { recursive: true });
        }

        fs.copyFileSync(sourcePath, backupPath);
        
        return backupPath;
    }
}

module.exports = ExcelService;
