# Quick Start Guide - Profit Dashboard

## 🚀 Getting Started in 3 Steps

### Step 1: Install & Run
```bash
# Navigate to project folder
cd profit-dashboard

# Install dependencies (first time only)
npm install

# Start the application
npm start
```

### Step 2: Select Period
1. Choose **Month** from dropdown (e.g., January)
2. Choose **Year** from dropdown (e.g., 2025)
3. Click **"Load Month Data"**
   - Creates Excel file if it doesn't exist
   - Shows the main dashboard

### Step 3: Add Your First Project
Fill in the form:
- **Project Name**: "Website Development"
- **No. of Engineers**: 3
- **Engineer Salary/Month**: $5,000
- **CE Visit Charge**: $200
- **Visits/Month**: 4
- **Transport Cost/Month**: $500
- **Client Payment/Month**: $20,000
- **Overhead Allocation (%)**: 15

Click **"Save Project"** and watch the dashboard update!

## 📊 What You'll See

### Summary Cards
- Total Projects: 1
- Total Revenue: $20,000
- Total Costs: $16,725
- Net Profit: $3,275

### Charts
All four charts update automatically with your project data.

### Excel File
Located at:
- Windows: `C:\Users\[You]\AppData\Roaming\profit-dashboard\excel-files\`
- Mac: `~/Library/Application Support/profit-dashboard/excel-files/`
- Linux: `~/.config/profit-dashboard/excel-files/`

## 💡 Pro Tips

1. **Monthly Organization**: Create separate files for each month to track trends
2. **Backup**: Files are automatically backed up in the `backups` folder
3. **Export**: Use "Export to Excel" to save copies anywhere
4. **Details**: Click "View" on any project to see the calculation breakdown
5. **Trends**: Add projects across multiple months to see trend charts

## ❓ Common Questions

**Q: Can I edit the Excel file directly?**
A: Yes! The Excel files use formulas, so they work in Excel/LibreOffice.

**Q: Where is my data stored?**
A: In Excel files in your user data folder (see paths above).

**Q: Can I use this offline?**
A: Absolutely! It's a desktop app that works 100% offline.

**Q: How do I back up my data?**
A: Just copy the `excel-files` folder to your backup location.

**Q: Can I run this on multiple computers?**
A: Yes! Just install on each computer or copy the `excel-files` folder.

## 🎯 Example Scenario

**Scenario**: Managing 3 projects in January 2025

1. Load January 2025
2. Add Project A: Web Development ($15,000 revenue, $12,000 cost)
3. Add Project B: Mobile App ($25,000 revenue, $18,000 cost)
4. Add Project C: Maintenance ($8,000 revenue, $5,000 cost)

**Results**:
- Total Revenue: $48,000
- Total Costs: $35,000
- Net Profit: $13,000
- Charts show comparison and trends

## 🔧 Troubleshooting

**Application won't start?**
```bash
# Reinstall dependencies
npm install
npm start
```

**Charts not showing?**
- Check internet connection (for CDN resources)
- Or use offline mode (modify HTML to use local Chart.js)

**Excel file missing?**
- Check the file paths above
- The app creates files automatically when you add projects

## 📞 Need Help?

1. Check the main README.md file
2. Review the code comments
3. Open the Developer Tools (Ctrl+Shift+I) to see errors

---

**Ready to track your profits? Let's go! 🚀**
